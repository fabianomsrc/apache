21 December 2012                                  Apache Lounge Distribution

                                     php5apache2_4.dll PHP 5.3 for Apache 2.4.x Win32

# binary by: Steffen
# Mail: info@apachelounge.com
# Home: http://www.apachelounge.com/



Runs with PHP 5.3 Thread Safe (TS), and only with Apache 2.4 Win32 VC9 or VC10



# Install:

- Copy php5apache2_4.dll to your php folder (eg. c:/php)


# Add to your httpd.conf

LoadModule php5_module "c:/php/php5apache2_4.dll"
AddHandler application/x-httpd-php .php

# configure the path to php.ini
PHPIniDir "C:/php"

Note: Remember to substitute the c:/php for your actual path to PHP in the above example.




Enjoy,

Steffen